
public enum Location {
	EARTH, BELT, MARS, RING 
}

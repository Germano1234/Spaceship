
public enum SeatCategory {
	NOSEAT, FIRST, BUSINESS, COACH
}
